---
title: "ArchivedContractMoneyUsd"
description: "yosoi.runtime_contracts.ArchivedContractMoneyUsd Python API reference."
order: 0
---

`yosoi.runtime_contracts.ArchivedContractMoneyUsd`

```python
class ArchivedContractMoneyUsd(ImmutableModel):
```

Store USD money as a portable signed minor-unit amount.

Attributes:
    type: Wire discriminator for archived USD values.
    minor_units: Signed 64-bit count of cents; the DTO bounds the integer without
        revalidating a Contract.

[Source: python/yosoi/runtime_contracts.py:223](https://github.com/CascadingLabs/Yosoi/blob/cfc578beb8e5a4ba3bb3955f1b918d20f2d75af3/python/yosoi/runtime_contracts.py#L223-L235)

Members below are declared on this class. Inherited Pydantic methods and generated constructor signatures are not expanded.

## Fields and class attributes

```python
type: Literal['money_usd']
minor_units: Annotated[int, Field(strict=True, ge=-2 ** 63, le=2 ** 63 - 1, repr=False)]
```
