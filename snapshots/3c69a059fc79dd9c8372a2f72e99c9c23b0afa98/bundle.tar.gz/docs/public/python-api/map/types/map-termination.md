---
title: "MapTermination"
description: "yosoi.map.MapTermination Python API reference."
order: 0
---

`yosoi.map.MapTermination`

```python
class MapTermination(ImmutableModel):
```

Why discovery stopped, independently of individual source success.

Attributes:
    kind: exhausted means no runnable work remains under policy, not exhaustive site
        coverage; limit, deadline, and cancelled stop further work while retaining
        evidence.
    value: Resource limit classification for limit, otherwise None.

[Source: python/yosoi/map.py:480](https://github.com/CascadingLabs/Yosoi/blob/3c69a059fc79dd9c8372a2f72e99c9c23b0afa98/python/yosoi/map.py#L480-L507)

Members below are declared on this class. Inherited Pydantic methods and generated constructor signatures are not expanded.

## Fields and class attributes

```python
kind: Literal['exhausted', 'limit', 'deadline', 'cancelled']
value: Literal['hosts', 'urls', 'relationships', 'observations', 'pending', 'requests', 'sitemaps', 'sitemap_depth', 'response_bytes', 'total_response_bytes', 'inventory_bytes', 'parser_entries'] | None = Field(default=None, exclude_if=lambda value: value is None)
```
