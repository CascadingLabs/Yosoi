---
title: "ArchivedContractField"
description: "yosoi.contracts.ArchivedContractField Python API reference."
order: 0
---

`yosoi.contracts.ArchivedContractField`

```python
ArchivedContractField = _runtime_contracts.ArchivedContractField
```

Pair an archived schema field ID with its accepted value.

Attributes:
    id: Identity of the field in the archive schema.
    value: Portable value with an explicit cardinality discriminator.

[Source: python/yosoi/contracts.py:1624](https://github.com/CascadingLabs/Yosoi/blob/3c69a059fc79dd9c8372a2f72e99c9c23b0afa98/python/yosoi/contracts.py#L1624-L1624)

[Definition](/yosoi/python-api/runtime-contracts/types/archived-contract-field/)

[Source: python/yosoi/runtime_contracts.py:266](https://github.com/CascadingLabs/Yosoi/blob/3c69a059fc79dd9c8372a2f72e99c9c23b0afa98/python/yosoi/runtime_contracts.py#L266-L275)
