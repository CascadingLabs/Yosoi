---
title: "Flow"
description: "yosoi.browser.Flow Python API reference."
order: 0
---

`yosoi.browser.Flow`

```python
class Flow(ImmutableModel):
```

Declare ordered browser steps without acquiring a Session.

Invocation either manages browser ownership or borrows an explicit Work lease.
JavaScript permission must be explicitly enabled for managed execution; a
borrowed Session retains its own permission policy.

Attributes:
    schema_version: Wire schema version; Until requires version 4, and legacy
        timeout_us implies version 1 when omitted.
    steps: Ordered immutable tuple of at most 128 steps.
    timeout: Optional total execution duration with explicit seconds/nanoseconds.
    timeout_us: Optional legacy total timeout in positive microseconds.
    on_failure: Flow failure continuation override; None uses policy defaults.
    on_cancellation: Flow cancellation continuation override; None uses policy
        defaults.
    capture_on_failure: Whether to attempt a screenshot when execution fails.

[Source: python/yosoi/browser.py:710](https://github.com/CascadingLabs/Yosoi/blob/dcb6411a41322c555092dda1df9bb0e49059b10d/python/yosoi/browser.py#L710-L792)

Members below are declared on this class. Inherited Pydantic methods and generated constructor signatures are not expanded.

## Fields and class attributes

```python
schema_version: Literal[1, 2, 3, 4] = 3
steps: tuple[Step, ...] = Field(default_factory=tuple, max_length=128)
timeout: Duration | None = None
timeout_us: PositiveU64 | None = None
on_failure: Continuation | None = None
on_cancellation: Continuation | None = None
capture_on_failure: Literal['disabled', 'screenshot'] = 'disabled'
```

## Methods

### to_json

```python
def to_json(self) -> str:
```

Return the Rust-validated, serde-compatible flow representation.

[Source: python/yosoi/browser.py:757](https://github.com/CascadingLabs/Yosoi/blob/dcb6411a41322c555092dda1df9bb0e49059b10d/python/yosoi/browser.py#L757-L759)

### allow_javascript

```python
def allow_javascript(self) -> Flow:
```

Return a Flow that explicitly permits JavaScript in managed invocation.

[Source: python/yosoi/browser.py:761](https://github.com/CascadingLabs/Yosoi/blob/dcb6411a41322c555092dda1df9bb0e49059b10d/python/yosoi/browser.py#L761-L765)

### with_timeout_ms

```python
def with_timeout_ms(self, timeout_ms: int) -> Flow:
```

Return a Flow with a total execution timeout expressed in milliseconds.

[Source: python/yosoi/browser.py:767](https://github.com/CascadingLabs/Yosoi/blob/dcb6411a41322c555092dda1df9bb0e49059b10d/python/yosoi/browser.py#L767-L776)

### bind

```python
def bind(self, policy: Policy) -> BoundFlow:
```

Bind a Rust-validated Policy to this immutable Flow.

[Source: python/yosoi/browser.py:778](https://github.com/CascadingLabs/Yosoi/blob/dcb6411a41322c555092dda1df9bb0e49059b10d/python/yosoi/browser.py#L778-L783)

### invoke

```python
async def invoke(self, lease: Work | None=None, *, cancellation: CancellationToken | None=None) -> FlowOutcome:
```

Run this Flow, optionally borrowing an already acquired Work lease.

[Source: python/yosoi/browser.py:785](https://github.com/CascadingLabs/Yosoi/blob/dcb6411a41322c555092dda1df9bb0e49059b10d/python/yosoi/browser.py#L785-L792)
